"""Native meshoptimizer shim for the Meshlet Preview addon.

Use ``library_path()`` to locate the bundled shared library and load
it with ctypes."""
import os

_LIB = 'libmeshopt_preview.dylib'

def library_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), _LIB)
